/**
 * A package with one main class for simultaing ObjectMulticlass.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.scripting.demo;