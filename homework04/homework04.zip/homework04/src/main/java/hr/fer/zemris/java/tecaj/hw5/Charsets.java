package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.Set;

/**
 * Command that returns the list of supported charsets.
 * @author Jura Šlosel
 *
 */
public class Charsets implements ShellCommand {

	/**
	 * Prints StandardCharsets supported by the JRE on this machine.
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) {
		Map<String, Charset> map = Charset.availableCharsets();
		Set<String> keys = map.keySet();
		for (String s :keys) {
			try {
				out.write(map.get(s).toString() + "\n");
			} catch (IOException e) {
				throw new BufferException("IOException. Can't print selected Charset!");
			}
		}
		return ShellStatus.CONTINUE;
	}

}
