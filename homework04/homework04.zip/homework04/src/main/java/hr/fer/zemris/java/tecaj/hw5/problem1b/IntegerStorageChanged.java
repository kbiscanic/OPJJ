package hr.fer.zemris.java.tecaj.hw5.problem1b;

/**
 * A class which encapsulates the previous and the current value stored in
 * the referenced IntegerStorage object. It is a link between the observer
 * and the object in the Observer pattern.
 * @author Jura Šlosel
 *
 */
public class IntegerStorageChanged {
	private IntegerStorage istorage;
	private int previousValue;
	private int newValue;
	
	/**
	 * Initializes the local fields.
	 * @param istorage the referenced IntegerStorage whose value has changed
	 * @param previousValue the previous value of IntegerStorage.value
	 * @param newValue the new value of IntegerStorage.value
	 */
	public IntegerStorageChanged(IntegerStorage istorage, int previousValue,
			int newValue) {
		super();
		this.istorage = istorage;
		this.previousValue = previousValue;
		this.newValue = newValue;
	}

	/**
	 * Getter.
	 * @return istorage
	 */
	public IntegerStorage getIstorage() {
		return istorage;
	}

	/**
	 * Getter.
	 * @return previousValue
	 */
	public int getPreviousValue() {
		return previousValue;
	}

	/**
	 * Getter.
	 * @return newValue
	 */
	public int getNewValue() {
		return newValue;
	}
	
}
