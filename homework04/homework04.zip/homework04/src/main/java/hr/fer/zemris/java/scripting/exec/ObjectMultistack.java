package hr.fer.zemris.java.scripting.exec;

import java.util.HashMap;
import java.util.Map;

/**
 * A class which acts like a Map with Strings for keys, and ValueWrapper stack for values.
 * @author Jura Šlosel
 *
 */
public class ObjectMultistack {
	private Map<String, MultistackEntry> map;
	
	/**
	 * Initializes the internally stored Map.
	 */
	public ObjectMultistack() {
		map = new HashMap<String, MultistackEntry>();
	}
	
	/**
	 * Sets the value joined to key {@code name} to be that of {@code valueWrapper}
	 * and remembers what was previously stored. Thus it has a push functionality.
	 * @param name
	 * @param valueWrapper
	 */
	public void push(String name, ValueWrapper valueWrapper) {
		MultistackEntry previous = map.get(name);
		map.put(name, new MultistackEntry(valueWrapper, previous));
	}
	
	/**
	 * Pops the specified stack.
	 * @param name the key of the stack we wish to pop
	 * @return the ValueWrapper popped
	 * @throws EmptyStackException if called stack is empty
	 */
	public ValueWrapper pop(String name) throws EmptyStackException {
		MultistackEntry popped = map.get(name);
		if (popped != null) {
			map.put(name, popped.previous);
			return popped.valueWrapper;
		}
		throw new EmptyStackException("You shall not pop! An empty stack.");
	}
	
	/**
	 * Peeks the specified stack.
	 * @param name the key of the stack we wish to peek
	 * @return the ValueWrapper peeked
	 * @throws EmptyStackException if called stack is empty
	 */
	public ValueWrapper peek(String name) throws EmptyStackException {
		MultistackEntry peeked = map.get(name);
		if (peeked != null) {
			return peeked.valueWrapper;
		}
		throw new EmptyStackException("You shall not peek! An empty stack.");
	}
	
	/**
	 * Check whether this ObjectMultistack is empty.
	 * @return true if empty, false if not
	 */
	public boolean isEmpty() {
		return map.isEmpty();
	}


	/**
	 * Acts like a node of a liked list. It stores a ValueWrapper object
	 * and the reference to another MultistackObject, should be set point to
	 * previous link in the chain.
	 * @author Jura Šlosel
	 *
	 */
	class MultistackEntry {
		protected ValueWrapper valueWrapper;
		protected MultistackEntry previous;
		
		/**
		 * Initializes the encapsulated ValueWrapper and the reference to another
		 * MultistackEntry.
		 * @param valueWrapper ValueWrapper to be stored
		 * @param previous a referenced MultistackEntry, should be the previous link in the chain
		 */
		public MultistackEntry(ValueWrapper valueWrapper, MultistackEntry previous) {
			super();
			this.valueWrapper = valueWrapper;
			this.previous = previous;
		}
	}
	
}
