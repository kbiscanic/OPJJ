package hr.fer.zemris.java.tecaj.hw5.problem1b;

import java.util.ArrayList;
import java.util.List;

/**
 * An implementation of the object in the Observer pattern with
 * multiple observers allowed.
 * @author Jura Šlosel
 *
 */
public class IntegerStorage {
	private int value;
	private List<IntegerStorageObserver> observers;
	
	/**
	 * Sets the initial value of {@code value}.
	 * @param initialValue the initial value of {@code value}
	 */
	public IntegerStorage(int initialValue) {
		this.value = initialValue;
		observers = new ArrayList<IntegerStorageObserver>();
	}
	
	/**
	 * Adds the passed observer to the list of active observers
	 * @param observer IntegerStorageObserver to be added to the list of active observers
	 */
	public void addObserver(IntegerStorageObserver observer) {
		observers.add(observer);
	}
	
	/**
	 * Removes the specified observer from the list of active observers. One must pass
	 * the exact reference to the IntegerStorageObserver one wishes to remove, not an
	 * artificial copy of the desired observer specified by the same type and parameters. 
	 * @param observer the IntegerStorageObserver to be removed from the list of active observers
	 */
	public void removeObserver(IntegerStorageObserver observer) {
		if (observers.contains(observer)) {
			observers.remove(observer);
		}
	}
	
	/**
	 * Removes the whole list of current observers.
	 */
	public void clearObserver() {
		this.observers = null;
	}
	
	/**
	 * Returns {@code value}.
	 * @return value
	 */
	public int getValue() {
		return value;
	}
	
	/**
	 * Sets {@code this.value} to {@code value} and tells the active observers a
	 * change has been made.
	 * @param value the new value of {@code this.value}
	 */
	public void setValue(int value) {
		if(this.value!=value) {
			IntegerStorageChanged change = new IntegerStorageChanged(this, this.value, value);
			this.value = value;
			if(observers!=null) {
				for (IntegerStorageObserver o : observers) {
					o.valueChanged(change);
				}
			}
		}
	}
	
}
