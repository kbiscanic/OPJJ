package hr.fer.zemris.java.tecaj.hw5;

/**
 * 
 * @author Jura Šlosel
 *
 */
public enum ShellStatus {
	CONTINUE,
	TERMINATE
}
