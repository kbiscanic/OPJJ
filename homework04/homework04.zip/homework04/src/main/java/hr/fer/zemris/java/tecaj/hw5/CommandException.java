package hr.fer.zemris.java.tecaj.hw5;

/**
 * Used for two different purposes: 1 if an IOException error occured
 * which we can't propagate; 2 if arguments of commands or some part of
 * sematics of command is somehow wrong 
 * @author Jura Šlosel
 *
 */
public class CommandException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CommandException(String message) {
		super (message);
	}
	
	public CommandException() {
		super ();
	}
}
