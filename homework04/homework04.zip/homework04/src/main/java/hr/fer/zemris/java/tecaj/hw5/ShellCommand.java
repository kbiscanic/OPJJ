package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;

/**
 * Basic interface implemented by all commands.
 * @author Jura Šlosel
 *
 */
public interface ShellCommand {

	/**
	 * Executes action joined to this command.
	 * @param in BufferedReader to read additional args from
	 * @param out BufferedWriter to write results to
	 * @param arguments
	 * @return not used
	 */
	ShellStatus executeCommand(BufferedReader in, BufferedWriter out, String[] arguments);
}
