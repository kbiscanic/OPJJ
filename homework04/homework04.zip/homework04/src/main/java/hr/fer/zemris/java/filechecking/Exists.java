package hr.fer.zemris.java.filechecking;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Class for an exists command. Holds its arguments: dir/file,
 * pathname, fail message, body of commands. Defines its execute().
 * @author Jura Šlosel
 *
 */
public class Exists extends Command {
	private boolean isDirectory;
	private String pathString;
	private ZipFile zip;
	
	/**
	 * Initializes fields.
	 * @param zip The zip file which we traverse in search for some file
	 * @param isDirectory first argument of exists - dir/file
	 * @param pathString String that represents the path to a file in zip
	 * @param positive true if no ! preceded 'exists', false otherwise
	 */
	public Exists(ZipFile zip, boolean isDirectory, String pathString, boolean positive) {
		this.isDirectory = isDirectory;
		this.pathString = pathString;
		this.positive = positive;
		this.children = new ArrayList<Command>();
		this.zip = zip;
	}

	/**
	 * Checks whether the file under the specified name exists
	 * in the zip. Constructs an error message if the test failed,
	 * and executes its children (hehe) if the test passed.
	 */
	@Override
	public void execute(List<String> errors) {
		ZipEntry entry = zip.getEntry(pathString);
		if (entry != null) {
			if(isDirectory && entry.isDirectory()) {
				testState = true;
			}
			if(!isDirectory && !entry.isDirectory()) {
				testState = true;
			}
		}
		if (!testState) {
			if (failMessage == null) {
				generateFailMessage();
			}
			errors.add(failMessage);
		} else {
			int size;
			if ((size = children.size()) != 0) {
				for (int i = 0; i < size; i++) {
					Command child = children.get(i);
					child.execute(errors);
				}
			}
		}
	}

	/**
	 * If no fail message was set, this sets a generic one.
	 */
	private void generateFailMessage() {
		failMessage = "An 'exists' command with no fail message has failed.\n" +
				"\tIt's arguments are: " + (isDirectory ? "dir" : "file") + 
				" " + pathString;
	}

}
