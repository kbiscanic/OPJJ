package hr.fer.zemris.java.tecaj.hw5.crypto;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * A class which allows encryption and decryption with AES and digesting
 * with SHA-1.
 * @author Jura Šlosel
 *
 */
public class Crypto {

	/**
	 * Receives from commandline instructions whether to digest or encrypt or decrypt
	 * a file, and the paths of files to work on.
	 * @param args either {"checksa", "\path\filename"} or 
	 * {"crypt", "\path1\inputfilename", "path2\outputfilename"}
	 * {"decrypt", "\path1\inputfilename", "path2\outputfilename"}
	 * @throws IOException 
	 * @throws GeneralSecurityException 
	 */
	public static void main(String[] args) throws IOException, GeneralSecurityException {
		if (args.length < 2 || args.length > 3) {
			throw new IllegalArgumentException(
					"You must provide exactly 2 or 3 arguments in commandline!");
		}
		
		if (args[0].toLowerCase().equals("checksha")) {
			if (args.length != 2) {
				throw new IllegalArgumentException("Wrong input for digesting!");
			}
			String digest = digestFile(args[1]);
			readDigestInput(digest);
			
		} else if (args[0].toLowerCase().equals("crypt")){
			if (args.length != 3) {
				throw new IllegalArgumentException("Wrong input for crypting!");
			}
			encrypt(args[1], args[2], true);
			
		} else if (args[0].toLowerCase().equals("decrypt")) {
			if (args.length != 3) {
				throw new IllegalArgumentException("Wrong input for decrypting!");
			}
			encrypt(args[1], args[2], false);
			
		}
		else {
			throw new IllegalArgumentException("Unknown command input!");
		}
	}

	/**
	 * Initializes the parameters for Cipher based on key and initialization vector
	 * to be input from console; and filenames specified here.
	 * @param inputFile String, name of input file
	 * @param outputFile String, name of output file
	 * @param encrypt true if we want to encrypt input to output, false if derypt
	 * @throws GeneralSecurityException
	 * @throws IOException
	 */
	private static void encrypt(String inputFile, String outputFile, boolean encrypt)
			throws GeneralSecurityException, IOException {
		String keyText =  readEncryptionInput("key");
		String ivText = readEncryptionInput("vector");
	
		SecretKeySpec keySpec = new SecretKeySpec(hextobyte(keyText), "AES");
		AlgorithmParameterSpec paramSpec = new IvParameterSpec(hextobyte(ivText));
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		cipher.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, keySpec, paramSpec);
		
		doEncrypt(cipher, inputFile, outputFile);
	}

	/**
	 * Does the actual encryption process via two Streams. A FileInputStream
	 * reads from input, encryption/decryption is done upon that data and 
	 * it is then sent to FileOutputStream.
	 * @param cipher The Cipher with all parameters initialized
	 * @param inputFile String, name of input file
	 * @param outputFile String, name of output file
	 * @throws FileNotFoundException
	 */
	private static void doEncrypt(Cipher cipher, String inputFile, String outputFile) 
			throws FileNotFoundException {
		
		try (FileInputStream inputStream = new FileInputStream(inputFile);
				FileOutputStream outputStream = new FileOutputStream(outputFile);) {
			//Create output file if it's missing
			File outFile = new File(outputFile);
			if (!outFile.exists()) {
				outFile.createNewFile();
			}
			File inFile = new File(inputFile);
			if (!inFile.exists()) {
				throw new FileNotFoundException("Input file doesn't exist!");
			}
			
			byte[] inputBytes = new byte[4096];
			byte[] outputBytes;
			int read;
			
			while ((read = inputStream.read(inputBytes)) != -1) {
				outputBytes = cipher.update(inputBytes, 0, read);
				outputStream.write(outputBytes);
			}
			
			outputBytes = cipher.update(inputBytes);
			
		} catch (IOException e) {
			System.out.println("Something went wrong while encrypting! (IOException): " +
					e.getMessage());
		}
		
		System.out.println("Done! Generated file " + outputFile + " based on " + inputFile);
				 
	}

	/**
	 * Converts the hexadecimal form of the AES key/initialization vector
	 *  to an array of bytes form.
	 * @param keyText hexadecimal key/initialization vector
	 * @return byte array key
	 */
	private static byte[] hextobyte(String keyText) {
		int size = keyText.length()/2;
		byte[] bytes = new byte[size];
		for (int i = 0; i < size; i++) {
			String hex = keyText.substring(2*i, 2*i + 2);
			byte elem = (byte)(Integer.valueOf(hex, 16).intValue());
			bytes[i] = elem;
		}
		return bytes;
	}

	/**
	 * Reads key and initialization vector for encryption/decryption.
	 * @param keyText String where key will be stored
	 * @param ivText String where initialization vector will be stored
	 * @throws IOException
	 */
	private static String readEncryptionInput(String text) throws IOException {		
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(System.in), "UTF-8"));
		
		String result;
		
		if (text.equals("key")) {
			System.out.println("Provide password as hex-encoded text.");
			result = bufferedReader.readLine();
			result = result.trim();

		} else {
			System.out.println("Provide initialization vector as hex-encoded text.");
			result = bufferedReader.readLine();
			bufferedReader.close();
			result = result.trim();
		}
		
		return result;
	}

	/**
	 * Reads expected digest of the specified file from console.
	 * @param digest expected digest
	 * @throws IOException
	 */
	private static void readDigestInput(String digest) throws IOException {
		System.out.println("Input your expected digest.");
		
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(System.in), "UTF-8"));
		
		String expected = bufferedReader.readLine();
		expected = expected.trim();
		bufferedReader.close();
		
		if (expected.equals(digest)) {
			System.out.println("The input digest maches the real digest.");
		} else {
			System.out.println("The input digest is false.");
			System.out.println("The real digest is: " + digest);
		}
	}

	/**
	 * Calculates the sha-1 digest of a file.
	 * @param file path of the file we wish to test
	 * @return hexadecimal digest as String
	 * @throws NoSuchAlgorithmException if SHA-1 is not supported
	 * @throws IOException
	 */
	private static String digestFile(String file) throws NoSuchAlgorithmException, IOException {
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
		
		BufferedInputStream buffer = new BufferedInputStream(
				new FileInputStream(file));
		
		byte[] bytes = new byte[4096];
		int read;
		while ((read = buffer.read(bytes)) != -1) {
			messageDigest.update(bytes, 0, read);
		}
		
		buffer.close();
		
		byte[] hash = messageDigest.digest();
		return getDigestCode(hash);
	}

	/**
	 * Transforms the byte[] form of digest into the String form.
	 * @param hash byte[], the calculated digest
	 * @return String form of digest
	 */
	private static String getDigestCode(byte[] hash) {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < hash.length; i++) {
			sb.append(String.format("%02X", hash[i] & 0xff));
		}
		return sb.toString().toLowerCase();
	}

}
