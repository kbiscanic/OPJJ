package hr.fer.zemris.java.tecaj.hw5.problem1b;

import hr.fer.zemris.java.tecaj.hw5.problem1b.IntegerStorageObserver;

/**
 * An implementation of the IntegerStorageObserver using IntegerStorageChanged.
 * @author Jura Šlosel
 *
 */
public class SquareValue implements IntegerStorageObserver {

	/**
	 * Prints the square of the new value stored in the IntegerStorage.
	 */
	@Override
	public void valueChanged(IntegerStorageChanged change) {
		int value = change.getNewValue();
		System.out.println("Provided new value, " + value + ", square is " + value*value);
	}
}
