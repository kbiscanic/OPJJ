package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Shell with commands: copy, mkdir, cat, hexdump, tree, ls, charsets.
 * Also, it has the option to change symbols used in the shell for
 * marking beginning of input or newline break...
 * @author Jura Šlosel
 *
 */
public class MyShell {

	/**
	 * 
	 * @param args not used
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Character PROMPTSYMBOL = '>';
		//goes on the end of the line where the command is broken in two lines
		Character MORELINESSYMBOL = '\\';
		//goes on the beggining of broken multiple line commands
		Character MULTILINESYMBOL = '|';
		
		Map<String, Character> symbols = new HashMap<String, Character>();
		symbols.put("prompt", PROMPTSYMBOL);
		symbols.put("morelines", MORELINESSYMBOL);
		symbols.put("multiline", MULTILINESYMBOL);
		
		Map<String, ShellCommand> commands = initializeCommandMap();
		
		BufferedReader stdIn = new BufferedReader(
				new InputStreamReader(System.in, "UTF-8"));
		
		BufferedWriter stdOut = new BufferedWriter(
				new OutputStreamWriter(System.out, "UTF-8"));
		
		while(true) {
			stdOut.write(symbols.get("prompt"));
			stdOut.flush();
			List<String> toExecute = readCommand(stdIn, stdOut, 
					symbols.get("morelines"), symbols.get("multiline"));
			
			//we give the symbol command special treatment
			if (toExecute != null && !toExecute.isEmpty() && 
					toExecute.get(0).toLowerCase().equals("symbol")) {
				callSymbol(toExecute, symbols, stdIn, stdOut);
			} else {
				callCommand(toExecute, commands, stdIn, stdOut);
			}
				
			stdOut.flush();
		}	
		
	}

	/**
	 * Prints or changes one of values of: PROMPT, MORELINES, MULTILINES.
	 * @param toExecute list of args
	 * @param symbols contains mapping of symbol names to values
	 * @param stdIn
	 * @param stdOut
	 */
	private static void callSymbol(List<String> toExecute, Map<String, Character> symbols, 
			BufferedReader in,BufferedWriter out) {
		int size = toExecute.size();
		if (size == 2) {
			String symbol = toExecute.get(1);
			if (symbol.equals("PROMPT")) {
				try {
					out.write("Symbol for PROMPT is " + symbols.get("prompt"));
					out.write("\n");
					out.flush();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			} else if (symbol.equals("MULTILINES")) {
				try {
					out.write("Symbol for MULTILINES is " + symbols.get("multiline"));
					out.write("\n");
					out.flush();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			} else if (symbol.equals("MORELINES")) {
				try {
					out.write("Symbol for MORELINES is " + symbols.get("morelines"));
					out.write("\n");
					out.flush();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			} else {
				try {
					out.write("Wrong input, symbols are: PROMPT, MORELINES, MULTILINES.");
					out.write("\n");
					out.flush();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			}
		}
		else if (size == 3) {
			String symbol = toExecute.get(1);
			Character symchar = toExecute.get(2).charAt(0);
			if (symbol.equals("PROMPT")) {
				try {
					out.write("Symbol for PROMPT changed from " + symbols.get("prompt") 
							+ " to " + symchar);
					symbols.put("prompt", symchar);
					out.write("\n");
					out.flush();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			} else if (symbol.equals("MULTILINES")) {
				try {
					out.write("Symbol for MULTILINES changed from " + symbols.get("multiline")
							+ " to " + symchar);
					symbols.put("multiline", symchar);
					out.write("\n");
					out.flush();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			} else if (symbol.equals("MORELINES")) {
				try {
					out.write("Symbol for MORELINES changed from " + symbols.get("morelines")
							+ " to " + symchar);
					symbols.put("morelines", symchar);
					out.write("\n");
					out.flush();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			} else {
				try {
					out.write("Wrong input, symbols are: PROMPT, MORELINES, MULTILINES.");
					out.write("\n");
					out.flush();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			}
		} else {
			wrongInput(out, "symbol");
		}
	}

	/**
	 * A method that determines which commands was read from input
	 * and calls the appropriate method with arguments passed.
	 * @param commandList list of commands
	 * @param commands Map of command names - ShellCommand pairs
	 * @param stdIn
	 * @param stdOut
	 * @throws IOException
	 */
	private static void callCommand(List<String> commandList, Map<String, ShellCommand> commands,
			BufferedReader stdIn, BufferedWriter stdOut) throws IOException  {
		if (commandList == null || commandList.isEmpty()) {
			return;
		}
		
		String name = commandList.get(0).toLowerCase();
		ShellCommand command;
		String[] args;
		ShellStatus returnValue = null;
		
		if (name.equals("cat")) {
				command = commands.get("cat");
			if (commandList.size() == 3) {
				args = new String[]{commandList.get(1), commandList.get(2)};
				returnValue = command.executeCommand(stdIn, stdOut, args);
			} else if (commandList.size() == 2) {
				args = new String[]{commandList.get(1)};
				try {
					returnValue = command.executeCommand(stdIn, stdOut, args);
				} catch (CommandException e){
					stdOut.write(e.getMessage());
					stdOut.flush();
				} catch (BufferException e) {
					System.err.println(e.getMessage());
				}
			} else {
				wrongInput(stdOut, "cat");
			}
		} 
		else if (name.equals("charsets")) {
			command = commands.get("charsets");
			if (commandList.size() > 1) {
				wrongInput(stdOut, "charsets");
			} else {
				try {
					returnValue = command.executeCommand(stdIn, stdOut, null);
				} catch (BufferException e) {
					System.err.println(e.getMessage());
				}
			}
		}
		else if (name.equals("copy")) {
			command = commands.get("copy");
			if (commandList.size() == 3) {
				args = new String[]{commandList.get(1), commandList.get(2)};
				try {
					returnValue = command.executeCommand(stdIn, stdOut, args);
				} catch (CommandException e){
					stdOut.write(e.getMessage());
					stdOut.flush();
				} catch (BufferException e) {
					System.err.println(e.getMessage());
				}
			} else {
				wrongInput(stdOut, "copy");
			}
		}
		else if (name.equals("exit")) {
			returnValue = ShellStatus.TERMINATE;
		}
		else if (name.equals("hexdump")) {
			command = commands.get("hexdump");
			if (commandList.size() != 2) {
				wrongInput(stdOut, "hexdump");
			} else {
				args = new String[]{commandList.get(1)};
				try {
					returnValue = command.executeCommand(stdIn, stdOut, args);
				} catch (CommandException e){
					stdOut.write(e.getMessage());
					stdOut.flush();
				} catch (BufferException e) {
					System.err.println(e.getMessage());
				}
			}
		}
		else if (name.equals("ls")) {
			command = commands.get("ls");
			if (commandList.size() != 2) {
				wrongInput(stdOut, "ls");
			} else {
				args = new String[]{commandList.get(1)};
				try {
					returnValue = command.executeCommand(stdIn, stdOut, args);
				} catch (CommandException e){
					stdOut.write(e.getMessage());
					stdOut.flush();
				} catch (BufferException e) {
					System.err.println(e.getMessage());
				}
			}
		}
		else if (name.equals("mkdir")) {
			command = commands.get("mkdir");
			if (commandList.size() != 2) {
				wrongInput(stdOut, "mkdir");
			} else {
				args = new String[]{commandList.get(1)};
				try {
					returnValue = command.executeCommand(stdIn, stdOut, args);
				} catch (CommandException e) {
					stdOut.write(e.getMessage());
				}
			}
		}
		else if (name.equals("tree")) {
			command = commands.get("tree");
			if (commandList.size() != 2) {
				wrongInput(stdOut, "tree");
			} else {
				args = new String[]{commandList.get(1)};
				try {
					returnValue = command.executeCommand(stdIn, stdOut, args);
				} catch (CommandException e) {
					stdOut.write(e.getMessage());
				}
			}
		}
		else {
			wrongInput(stdOut);
		}
		
		if (returnValue == ShellStatus.TERMINATE) {
			try {
				stdOut.flush();
				stdOut.close();
				stdIn.close();
			} catch (IOException e) {
				System.err.println("An IOException occured when closing Buffers!");
			}
			
			System.exit(-1);
		}
	
	}

	/**
	 * Called if a command name has been recognized, but the arguments are wrong
	 * in number.
	 * @param string the name of the command whose argument count was missed
	 * @throws IOException
	 */
	private static void wrongInput(BufferedWriter out, String string) {
		try {
			out.write("Wrong number of arguments for command ("+string+") has been given.\n");
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}	
	}

	/**
	 * Called if a command name wasn't recognized.
	 * @throws IOException
	 */
	private static void wrongInput(BufferedWriter out) {
		try {
			out.write("The command name was not recognized!\n");
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}		
	}

	/**
	 * Reads a line (or lines) from input, collects arguments of the
	 * command in a List it returns.
	 * @param stdIn
	 * @param stdOut
	 * @param MORELINESSYMBOL
	 * @param MULTILINESYMBOL
	 * @return List<String> of arguments for command
	 * @throws IOException
	 */
	private static List<String> readCommand(BufferedReader stdIn, BufferedWriter stdOut, 
			char MORELINESSYMBOL, char MULTILINESYMBOL) throws IOException {
		
		String line;
		List<String> commandsList = new ArrayList<String>();
		//this we use to count multilines
		int moreLines = 0;
		do {
			if (moreLines > 0) {
				stdOut.write(MULTILINESYMBOL);
				stdOut.flush();
			}
			
			line = stdIn.readLine();
			if (line == null) break;
			
			String tmp = new String(line);
			if (line.endsWith("" + MORELINESSYMBOL + "")) {
				tmp = tmp.substring(0, tmp.length() - 1);
			}
			tmp = tmp.trim();
			
			String[] lineParts = tmp.split(" +?");
			for (String s : lineParts) {
				if (!s.equals("")) {
					commandsList.add(s);
				}
			}
			moreLines++;
		} while (line.endsWith("" + MORELINESSYMBOL + ""));
		
		return commandsList;
	}

	/**
	 * Initialize the Map of commands - it maps names of commands to their
	 * respective ShellCommand.
	 * @return initialized Map<String, ShellCommand>
	 */
	private static Map<String, ShellCommand> initializeCommandMap() {
		Map<String, ShellCommand> map = new HashMap<String, ShellCommand>();
		map.put("cat", new Cat());
		map.put("charsets", new Charsets());
		map.put("copy", new Copy());
		map.put("hexdump", new HexDump());
		map.put("ls", new Ls());
		map.put("mkdir", new MkDir());
		map.put("tree", new Tree());
		return map;
	}

}
