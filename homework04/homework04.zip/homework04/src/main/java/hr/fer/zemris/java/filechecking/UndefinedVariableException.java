package hr.fer.zemris.java.filechecking;

/**
 * In case when in a string we encounter a usage of a variable
 * that wasn't declared beforehand.
 * @author Jura Šlosel
 *
 */
public class UndefinedVariableException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UndefinedVariableException(String message) {
		super(message);
	}
}
