package hr.fer.zemris.java.scripting.exec;

/**
 * A RuntimeException when an empty stack was popped or peeked.
 * @author Jura Šlosel
 *
 */
public class EmptyStackException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Simply calls super() with no arguments.
	 */
	public EmptyStackException() {
		super();
	}
	
	/**
	 * Constructor with a message to be printed.
	 * @param message exception description
	 */
	public EmptyStackException(String message) {
		super(message);
	}
	
}
