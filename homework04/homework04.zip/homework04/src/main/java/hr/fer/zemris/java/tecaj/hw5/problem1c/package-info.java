/**
 * Contains a program for output of statistical data of files and directories
 * in a specified part of the filesystem hierarchy.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.tecaj.hw5.problem1c;