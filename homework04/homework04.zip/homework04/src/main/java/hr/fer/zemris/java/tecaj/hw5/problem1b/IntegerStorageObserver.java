package hr.fer.zemris.java.tecaj.hw5.problem1b;

import hr.fer.zemris.java.tecaj.hw5.problem1b.IntegerStorageChanged;

/**
 * An interface that represents an observer-action that is to be taken upon an
 * observed object when the object has been changed. It is the observer in
 * the Observer pattern.
 * @author Jura Šlosel
 *
 */
public interface IntegerStorageObserver {
	/**
	 * Action to be done upon the IntegerStorage object.
	 * @param istorage the object in the Observer pattern
	 */
	void valueChanged(IntegerStorageChanged istorage);
}
