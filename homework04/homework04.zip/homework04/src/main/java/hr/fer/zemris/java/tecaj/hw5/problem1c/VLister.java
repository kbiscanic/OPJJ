package hr.fer.zemris.java.tecaj.hw5.problem1c;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A program for traversing a tree in filesystem hierarchy and printing
 * a statistics of its contents in a few possible listings.
 * @author Jura Šlosel
 *
 */
public class VLister {

	/**
	 * Creates a map of all extension types in the path, then reads from console
	 * how the output of this map should be made.
	 * @param args one argument, the path in FS hierarchy of the tree to traverse
	 * @throws IOException
	 */
	public static void main(String args[]) throws IOException {
		if (args.length != 1) {
			throw new IllegalArgumentException("You must input 1 argument in commandline!");
		}
		
		Path path = Paths.get(args[0]);
		
		ExtensionCollection extMap = new ExtensionCollection();
		TotalCount totalCount = new TotalCount();
		
		Files.walkFileTree(path, new MyVisitor(extMap, totalCount));
		
		List<ExtensionData> extensionList = new ArrayList<ExtensionData>(extMap.extMap.values());
		
		readSortCommands(extensionList, totalCount);
		
	}
	
	/**
	 * Enables reading from console so the user may input wished actions.
	 * @param extensionList List of all ExtensionData, stored here to be easily sorted
	 * @param totalCount the TotalCount statistic
	 * @throws IOException
	 */
	private static void readSortCommands(List<ExtensionData> extensionList,
			TotalCount totalCount) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(System.in), "UTF-8"));
		while(true) {
			String line = bufferedReader.readLine();
			line = line.trim();
			if(line.equals("Q")) {
				break;
			}
			if(line.isEmpty()) {
				continue;
			}
			if (line.equals("G") || line.equals("E") || line.equals("!E")
					|| line.equals("A") || line.equals("!A") || line.equals("S")
					|| line.equals("!S") || line.equals("N") || line.equals("!N")) {
				sortAndOutput(line, extensionList, totalCount);
			} else {
				System.out.println("\nWrong input! Must input: G, E, !E, N, !N, S, !S, A or !A\n");
			}			
		}
		bufferedReader.close();
	}

	/**
	 * Defines 4 possible Comparators, determines which of them the user whishes to use
	 * and then prints the statistic accordingly.
	 * @param line one of: E, !E, G, A, !A, S, !S, N, !N
	 * @param extensionList List of ExtensionData
	 * @param totalCount our TotalCount statistics
	 */
	private static void sortAndOutput(String line, List<ExtensionData> extensionList,
			TotalCount totalCount) {
		Comparator<ExtensionData> comparatorE = new Comparator<ExtensionData>() {
			@Override
			public int compare(ExtensionData o1, ExtensionData o2) {
				return o1.name.compareTo(o2.name);
			}
		};
		
		Comparator<ExtensionData> comparatorS = new Comparator<ExtensionData>() {
			@Override
			public int compare(ExtensionData o1, ExtensionData o2) {
				return VLister.compare(o1.filesSize, o2.filesSize);
			}
		};
		
		Comparator<ExtensionData> comparatorN = new Comparator<ExtensionData>() {
			@Override
			public int compare(ExtensionData o1, ExtensionData o2) {
				return VLister.compare(o1.filesCount, o2.filesCount);
			}			
		};
		
		Comparator<ExtensionData> comparatorA = new Comparator<ExtensionData>() {
			@Override
			public int compare(ExtensionData o1, ExtensionData o2) {
				return (new Double(o1.averageFileSize()).compareTo(
						new Double(o2.averageFileSize())));
			}
		};
		
		if (line.equals("E")) Collections.sort(extensionList, comparatorE);
		else if (line.equals("S")) Collections.sort(extensionList, comparatorS);
		else if (line.equals("N")) Collections.sort(extensionList, comparatorN);
		else if (line.equals("A")) Collections.sort(extensionList, comparatorA);
		
		else if (line.equals("!E")) Collections.sort(extensionList, 
				new LyingComparator<ExtensionData>(comparatorE));
		else if (line.equals("!S")) Collections.sort(extensionList, 
				new LyingComparator<ExtensionData>(comparatorS));
		else if (line.equals("!N")) Collections.sort(extensionList, 
				new LyingComparator<ExtensionData>(comparatorN));
		else if (line.equals("!A")) Collections.sort(extensionList, 
				new LyingComparator<ExtensionData>(comparatorA));
		
		else if (line.equals("G")) {
			printTotal(totalCount);
			return;
		}
		
		for(ExtensionData ext : extensionList) {
			System.out.println("(" + ext.name + ") : total file size = " + ext.filesSize +
					", files count = " + ext.filesCount + ", average file size = " +
					ext.averageFileSize());
		}
		
		System.out.println("\n");
		
	}

	/**
	 * Print TotalCount statistics.
	 * @param totalCount TotalCount statistics
	 */
	private static void printTotal(TotalCount totalCount) {
		System.out.println("Total files count = " + totalCount.fileCount);
		System.out.println("Total files size = " + totalCount.totalFileSize);
		System.out.println("Average files size = " + totalCount.averageFileSize());
		System.out.println("Total directories count = " + totalCount.dirCount);
	}

	/**
	 * A Comparator which wraps a real Comparator and creates a reverse ordering
	 * of data than that provided by the real Comparator.
	 * @author Jura Šlosel
	 *
	 * @param <ExtensionData>
	 */
	private static class LyingComparator<ExtensionData> implements Comparator<ExtensionData> {
		Comparator<ExtensionData> realComparator;
		
		public LyingComparator(Comparator<ExtensionData> realComparator) {
			this.realComparator = realComparator;
		}
		
		@Override
		public int compare(ExtensionData o1, ExtensionData o2) {
			return -realComparator.compare(o1, o2);
		}
	}

	/**
	 * 
	 * @param int1
	 * @param int2
	 * @return
	 */
	private static int compare(long int1, long int2) {
		if (int1 > int2) {
			return 1;
		} else if (int1 < int2) {
			return -1;
		}
		return 0;
	}
	
	/**
	 * A class which represents one input in the ExtensionCollection, 
	 * it holds statistical data for a group of files with the same extension.
	 * File size, number, and average size are stored, as is the extension name.
	 * @author Jura Šlosel
	 *
	 */
	static class ExtensionData {
		protected int filesCount;
		protected long filesSize;
		protected String name;
		
		public ExtensionData(String name) {
			this.name = name;
		}
		
		protected double averageFileSize() {
			return filesCount == 0 ? 0.0 : filesSize / filesCount;
		}
	}
	
	/**
	 * A mapping of extension names to their statistics (ExtensionData).
	 * It also implements some methods which are used by FileVisitior in
	 * walkFileTree().
	 * @author Jura Šlosel
	 *
	 */
	static class ExtensionCollection {
		protected Map<String, ExtensionData> extMap;
		
		public ExtensionCollection() {
			extMap = new HashMap<String, ExtensionData>();
		}
		
		/**
		 * Action to be taken by FileVisitor when a file is encountered.
		 * @param file file encountered
		 */
		void addFile(File file) {
			String extension = getExtension(file.getName());
			if (extension == null) {
				return;
			}
			
			ExtensionData data = extMap.get(extension);
			if (data == null) {
				data = new ExtensionData(extension);
				extMap.put(extension, data);
			}
			
			data.filesCount++;
			data.filesSize += file.length();
		}

		/**
		 * Gets the extension of the current file.
		 * @param name name of file
		 * @return extension of the file if such exists
		 */
		private String getExtension(String name) {
			int dotPosition = name.lastIndexOf('.');
			if (dotPosition < 1){
				return null;
			}
			
			String ext = name.substring(dotPosition);
			if (ext.isEmpty()) {
				return null;
			}
			
			return ext.toLowerCase();
		}
		
	}
	
	/**
	 * A class for global statistics of directories and files.
	 * @author Jura Šlosel
	 *
	 */
	static class TotalCount {
		protected int dirCount;
		protected int fileCount;
		protected int totalFileSize;
		
		protected double averageFileSize() {
			return fileCount == 0 ? 0.0 : totalFileSize / fileCount;
		}
	
		void fileOperation(File file) {
			fileCount++;
			totalFileSize += file.length();
		}
		
		void dirOperation() {
			dirCount++;
		}
		
	}
	
	/**
	 * Implementation of the FileVisitor used here specifically to fill out our
	 * statistical data while traversing the file tree.
	 * @author Jura Šlosel
	 *
	 */
	static class MyVisitor implements FileVisitor<Path> {
		protected ExtensionCollection extMap;
		protected TotalCount totalCount;
		
		public MyVisitor(ExtensionCollection extCol, TotalCount totCount) {
			extMap = extCol;
			totalCount = totCount;
		}

		@Override
		public FileVisitResult preVisitDirectory(Path dir,
				BasicFileAttributes attrs) throws IOException {
			totalCount.dirOperation();
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
				throws IOException {
			extMap.addFile(file.toFile());
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc)
				throws IOException {
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc)
				throws IOException {
			return FileVisitResult.CONTINUE;
		}
		
	}
	
}
