package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;

/**
 * Standard mkdir command.
 * @author Jura Šlosel
 *
 */
public class MkDir implements ShellCommand {

	/**
	 * Creates the wanted directory and the whole path if parts of it
	 * dont't yet exist. 
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) {
		
		File dir = new File(arguments[0]);
		
		if(dir.exists()) {
			throw new CommandException("The directory already exists.");
		}
		
		dir.mkdirs();
		
		return ShellStatus.CONTINUE;
	}

}
