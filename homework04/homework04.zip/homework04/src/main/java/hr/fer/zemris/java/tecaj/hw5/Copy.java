package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Copy src dest.
 * @author Jura Šlosel
 *
 */
public class Copy implements ShellCommand {

	/**
	 * Copies argument[0] to argument[1].
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) {
		File source = new File(arguments[0]);
		File dest = new File(arguments[1]);
		
		sourceCheck(source, out);
		
		if (dest.isDirectory()) {
			dest = new File(dest, dest.getName());
		}
		
		if (dest.exists()) {
			askUser(dest, in, out);
		}

		Path from = source.toPath();
		Path to = dest.toPath();
		
		CopyOption[] options = new CopyOption[]{
			StandardCopyOption.REPLACE_EXISTING,
			StandardCopyOption.COPY_ATTRIBUTES
		}; 
		
		try {
			Files.copy(from, to, options);
		} catch (IOException e) {
			throw new CommandException("Could not copy file!\n");
		}
		
		return ShellStatus.CONTINUE;
	}

	/**
	 * If a destination File already exists, we check with the user if it's 
	 * okay to overwrite.
	 * @param dest File, destination
	 * @param in BufferReader, stdIn
	 * @param out BufferWriter, stdOut
	 */
	private void askUser(File dest, BufferedReader in, BufferedWriter out) {
		try {
			out.write("The file "+dest.getAbsolutePath()+" already exists. Overwrite? (y/n)\n");
		} catch (IOException e) {
			throw new BufferException("Failed to print to output!");
		}
		while(true) {
			String input;
			try {
				input = in.readLine();
			} catch (IOException e) {
				throw new BufferException("Failed to read from output!");
			}
			if (input.toLowerCase().equals("y")) {
				break;
			}
			if (input.toLowerCase().equals("n")) {
				throw new CommandException("");
			}
		}
	}

	/**
	 * Checks whether source is a directory or non existent, which isn't allowed.
	 * @param source File, source
	 * @param out BufferWriter, stdOut
	 */
	private void sourceCheck(File source, BufferedWriter out) {
		if (source.isDirectory()) {
			throw new CommandException(source.getName() + " is a directory and cannot be copied.\n");
		}
		
		if (!source.exists()) {
			throw new CommandException(source.getName() + " doesn't exist and cannot be copied.\n");
		}
		
	}

}
