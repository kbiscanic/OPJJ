package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Class for printing the hexdump of a file.
 * @author Jura Šlosel
 *
 */
public class HexDump implements ShellCommand {

	/**
	 * Prints the hexdump of a file (no directory) to out.
	 * @param arguments file path
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) {
		
		if ((new File(arguments[0])).isDirectory()) {
			throw new CommandException("Cant hexdump directory\n");
		}
		
		FileInputStream fstream;
		try {
			fstream = new FileInputStream(arguments[0]);
		} catch (IOException e) {
			throw new CommandException("Input file doesn't exist!\n");
		}
		
		byte[] dump = new byte[16];
		
		try {
			int counter = 0;
			while(fstream.read(dump) != -1) {
				out.write(String.format("%08X", counter));
				out.write("|");
				counter += 16;
				
				printMiddle(dump, out);
				printEnd(dump, out);
				
				out.write("\n");
				out.flush();
			}
		} catch (IOException e) {
			throw new BufferException("Problems reading from file.");
		}
		
		try {
			fstream.close();
		} catch (IOException e) {
		}
		
		return ShellStatus.CONTINUE;
	}

	/**
	 * Prints the ascii representation of bytes contained in the file.
	 * @param dump byte[] to be converted ascii chars
	 * @param out BufferedWriter, stdOut
	 */
	private void printEnd(byte[] dump, BufferedWriter out) {
		for (int i = 0; i < dump.length; i++) {
			if (dump[i] < 32 || dump[i] > 127) {
				dump[i] = 46;
			}
		}
		try {
			out.write(new String(dump));
		} catch (IOException e) {
			throw new BufferException();
		}
	}

	/**
	 * Prints the bytes of a file in hexadecimal form
	 * @param dump byte[] to be converted hexadecimal values
	 * @param out BufferedWriter, stdOut
	 */
	private void printMiddle(byte[] dump, BufferedWriter out) {
		for (int i = 0; i < 16; i++) {
			try {
				if (dump.length >= i) {
					out.write(String.format("%02X", dump[i]));
				} else {
					out.write("  ");
				}
				if (i % 8 == 7) {
					out.write("|");
				} else {
					out.write(" ");
				}
			} catch (IOException e){
				throw new BufferException("Problems while printing hexdump!");
			}
		}
	}

}
