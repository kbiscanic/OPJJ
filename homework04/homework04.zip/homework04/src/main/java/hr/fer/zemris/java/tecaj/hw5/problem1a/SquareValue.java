package hr.fer.zemris.java.tecaj.hw5.problem1a;

/**
 * An implementation of the IntegerStorageObserver observer.
 * @author Jura Šlosel
 *
 */
public class SquareValue implements IntegerStorageObserver {

	/**
	 * Prints the square of the new value stored in the IntegerStorage.
	 */
	@Override
	public void valueChanged(IntegerStorage istorage) {
		int value = istorage.getValue();
		System.out.println("Provided new value, " + value + ", square is " + value*value);
	}
}
