/**
 * A demonstration of the Filechecking.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.filechecking.demo;