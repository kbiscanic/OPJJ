package hr.fer.zemris.java.tecaj.hw5.problem1a;

/**
 * A class which simulates a use of the Observer pattern through IntegerStorage
 * class as the object and IntegerStorageObserver as the observer.
 * @author Jura Šlosel
 *
 */
public class ObserverExample {

	/**
	 * Creates an IntegerStorage and two observers, then simulates their
	 * reactions on changing the value stored in IntegerStorage.
	 * @param args not used
	 */
	public static void main(String[] args) {
		IntegerStorage istorage = new IntegerStorage(20);
		IntegerStorageObserver observer = new SquareValue();
		
		istorage.setObserver(observer);
		
		istorage.setValue(5);
		istorage.setValue(2);
		istorage.setValue(25);
		
		istorage.setObserver(new ChangeCounter());
		
		istorage.setValue(13);
		istorage.setValue(22);
		istorage.setValue(15);
	}

}
