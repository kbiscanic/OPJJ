package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.sql.Date;
import java.text.SimpleDateFormat;

/**
 * Command List (directory name).
 * @author Jura Šlosel
 *
 */
public class Ls implements ShellCommand {

	/**
	 * A ShellComand which accepts a directory (File) and prints its
	 * contents to out (BufferWriter, stdOut), alongside usual details.
	 * @param arguments path of directory to list
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) {
		File dir = new File(arguments[0]);
		
		checkDirectory(dir, out);
		
		File[] children = dir.listFiles();
		for(File file : children) {
			basicInfo(file, out);
			fileSize(file, out);
			dateOfCreation(file, out);
			fileName(file, out);
		}
		
		return ShellStatus.CONTINUE;
	}

	/**
	 * Print name of file to out.
	 * @param file File
	 * @param out BufferWriter, stdOut
	 */
	private void fileName(File file, BufferedWriter out) {
		try {
			out.write(file.getName());
			out.write(" \n");
			out.flush();
		} catch (IOException e) {
			throw new BufferException("Exception while writing to stdOut!");
		}
	}

	/**
	 * Print Date and time of creation of the file to out.
	 * @param file File
	 * @param out BufferWriter, stdOut
	 */
	private void dateOfCreation(File file, BufferedWriter out) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		Path path = file.toPath();
		BasicFileAttributeView faView = Files.getFileAttributeView(
				path, BasicFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
		BasicFileAttributes attributes;
		try {
			attributes = faView.readAttributes();
		} catch (IOException e) {
			throw new CommandException("Couldn't acces a file in this dir!\n");
		}
		FileTime fileTime = attributes.creationTime();
		String formattedDateTime = sdf.format(new Date(fileTime.toMillis()));
		try {
			out.write(formattedDateTime);
			out.write(" ");
			out.flush();
		} catch (IOException e) {
			throw new BufferException("Exception while writing to stdOut!");
		}
	}
	
	/**
	 * Print file size to out.
	 * @param file File
	 * @param out BufferWriter, stdOut
	 */
	private void fileSize(File file, BufferedWriter out) {
		try {
			out.write(String.format("%10d", file.length()));
			out.write(" ");
			out.flush();
		} catch (IOException e) {
			throw new BufferException("Exception while writing to stdOut!");
		}
	}

	/**
	 * Print "drwx" column of a file, to out.
	 * @param file File
	 * @param out BufferWriter, stdOut
	 */
	private void basicInfo(File file, BufferedWriter out) {
		try {
			if (file.isDirectory()) {
				out.write("d");
			} else {
				out.write("-");
			}
			if (file.canRead()) {
				out.write("r");
			} else {
				out.write("-");
			}
			if (file.canWrite()) {
				out.write("w");
			} else {
				out.write("-");
			}
			if (file.canExecute()) {
				out.write("x");
			} else {
				out.write("-");
			}
			out.write(" ");
			out.flush();
		} catch (IOException e) {
			throw new BufferException("Couldn't write!");
		}
	}

	/**
	 * Check whether the passed file is a directory or not. Only for
	 * directories does the ls command exist.
	 * @param dir File for which we check to be a directory
	 * @param out BufferWriter, stdOut
	 */
	private void checkDirectory(File dir, BufferedWriter out) {
		if (!dir.exists()) {
			throw new CommandException("The specified directory doesn't quite exist!\n");
		}
		
		if (!dir.isDirectory()) {
			throw new CommandException("The passed argument is no directory!\n");
		}
	}
}
