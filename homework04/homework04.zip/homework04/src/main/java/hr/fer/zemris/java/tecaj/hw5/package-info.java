/**
 * Contains a shell to be run from commandline.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.tecaj.hw5;