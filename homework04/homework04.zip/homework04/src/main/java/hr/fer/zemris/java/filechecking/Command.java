package hr.fer.zemris.java.filechecking;

import java.util.List;

/**
 * An abstract class for exists, fail, filename, format Commands.
 * These can have a body of another command block within them or 
 * a fail message or a negation (a ! in front of command) and therefore
 * are very different from others. 
 * @author Jura Šlosel
 *
 */
public abstract class Command {
	protected List<Command> children;
	protected String failMessage;
	protected boolean positive;
	protected boolean testState = false;

	public abstract void execute(List<String> errors);
	
	public List<Command> getChildren() {
		return children;
	}
	
	public boolean hasChildren() {
		return !children.isEmpty();
	}
	
	public String getFailMessage() {
		return failMessage;
	}
	
	public void setFailMessage(String failMessage) {
		this.failMessage = failMessage;
	}
	
}
