package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;

/**
 * Command of concatenation.
 * @author Jura Šlosel
 *
 */
public class Cat implements ShellCommand {

	/**
	 * Prints the textual content of the specified File (not a directory),
	 * with the specified
	 * @param arguments file path, charset (not necessary)
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) {
		
		File file = new File(arguments[0]);
		if (!file.exists()) {
			throw new CommandException("The specified file doesn't exist!");
		}
		
		if (file.isDirectory()) {
			throw new CommandException("This isn't made for directories!");
		}
		
		try {
			Charset charset;
			if (arguments.length == 2) {
				charset = Charset.forName(arguments[1]);
			} else {
				charset = Charset.defaultCharset();
			}
			byte[] bytes = new byte[50];
			
			FileInputStream fstream = new FileInputStream(arguments[0]); 
			int read;
			while ((read = fstream.read(bytes)) != -1) {
				out.write(new String(bytes, 0, read, charset));
				out.write("\n");
				out.flush();
			}
			
			fstream.close();
		} catch (IOException e) {
			throw new BufferException("IOException occured while reading file.");
		}
		return null;
	}

}
