package hr.fer.zemris.java.filechecking;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

/**
 * A class which initializes parsing a program we know to be well written.
 * Everything needed for executing commands is stored in this class,
 * as is the list of errors.
 * @author Jura Šlosel
 *
 */
public class FCFileVerifier {
	private List<Command> commands;
	private Stack<List<Command>> stack;
	private Map<String, String> variablesMap;
	private List<String> errors;
	private Map<String, Object> initialData;
	private File file;
	private String fileName;
	private int lineNumber;
	private ZipFile zip;
	
	/**
	 * Initializes data.
	 * @param file (zip) file whose file tree we shall traverse
	 * @param fileName original name of the (zip) file
	 * @param program String form of actions and queries to do on the (zip) file
	 * @param initialData I don't really know
	 * @throws IOException 
	 * @throws ZipException 
	 */
	public FCFileVerifier (File file, String fileName, String program,
			Map<String, Object> initialData) throws ZipException, IOException {
		this.initialData = initialData;
		this.file = file;
		this.zip = new ZipFile(file);
		this.fileName = fileName;
		this.variablesMap = new HashMap<String, String>();
		this.errors = new ArrayList<String>();
		this.commands = new ArrayList<Command>();
		this.stack = new Stack<List<Command>>();
		
		setInitialTags();
		stack.push(commands);
		startCheck(program);
	}
	
	/**
	 * Puts tags from initialData into variablesMap stored here.
	 */
	private void setInitialTags() {
		Set<String> set = initialData.keySet();
		for(String key : set) {
			Object obj = initialData.get(key);
			variablesMap.put(key, obj.toString());
		}
	}

	/**
	 * Initiate reading the file.
	 * @param program the text of the file
	 */
	private void startCheck(String program) {
		Scanner lineScanner = new Scanner(program);
		checkBody(lineScanner);
		lineScanner.close();
		searchForErrors(commands);
	}

	private void searchForErrors(List<Command> commands) {
		int size = commands.size();
		for(int i = 0; i < size; i++) {
			Command command = commands.get(i);
			command.execute(errors);
		}
	}

	/**
	 * Reads the text line per line and determines which command-method to
	 * initiate. It is made so it works both for the whole document as
	 * for the block enclosed within {}.
	 * @param lineScanner returns the list of commands that belong to the same block,
	 * 						the one that was now worked on. it isn't used.
	 */
	private List<Command> checkBody(Scanner lineScanner) {
		while(lineScanner.hasNextLine()) {
			Scanner wordScanner = new Scanner(lineScanner.nextLine());
			lineNumber++;
			String name = wordScanner.next().toLowerCase();
			if (name.equals("def")) {
				def(wordScanner);
			}
			else if (name.equals("terminate")) {
				terminate(wordScanner);
			}
			else if (name.equals("exists") || name.equals("!exists")) {
				exists(lineScanner, wordScanner, !name.contains("!"));
			}
			else if (name.equals("filename") || name.equals("!filename")) {
				filename(lineScanner, wordScanner, !name.contains("!"));
			}
			else if (name.equals("fail") || name.equals("!fail")) {
				fail(lineScanner, wordScanner, !name.contains("!"));
			}
			else if (name.equals("format") || name.equals("!format")) {
				format(lineScanner, wordScanner, !name.contains("!"));
			}
			else if (name.equals("}")) {
				wordScanner.close();
				return stack.pop();
			}
		}
		return stack.pop();
	}

	/**
	 * Puts a variable input in variablesMap, joined with its value -
	 * a String path of a file.
	 * @param wordScanner Scanner of a line with def command
	 */
	private void def(Scanner wordScanner) {
		String variable = wordScanner.next();
		String string = extractString(wordScanner);
		String path = "";
		try {
			path = substituteVariables(string);
		} catch (UndefinedVariableException e) {
			System.out.println(e.getMessage());
			System.exit(-1);
		}
		//File file = new File(path);
		//variablesMap.put(variable, file);
		variablesMap.put(variable, path);
	}

	/**
	 * Creates a new Exists object with all its respective arguments
	 * read from the Scanner.
	 * @param lineScanner a Scanner of the remaining text
	 * @param wordScanner a Scanner of the line with exists command
	 */
	private void exists(Scanner lineScanner, Scanner wordScanner, boolean positive) {
		boolean isDirectory = isItDirectory(wordScanner.next());
		String string = extractString(wordScanner);
		try {
			string = substituteVariables(string);
		} catch (UndefinedVariableException e) {
			System.out.println(e.getMessage());
			System.exit(-1);
		}
		Exists exists = new Exists(zip, isDirectory, string, positive);
		List<Command> list = stack.peek();
		list.add(exists);
		if (wordScanner.hasNext()) {
			//What now? ovo je i za test i za {
			testsAndBracketsCheck(exists, lineScanner, wordScanner);
		}
	}

	/**
	 * Creates a new Fail object with all its respective arguments
	 * read from the Scanner.
	 * @param lineScanner a Scanner of the remaining text
	 * @param wordScanner a Scanner of the line with exists command
	 */
	private void fail(Scanner lineScanner, Scanner wordScanner, boolean positive) {
		Fail fail = new Fail(positive); //this is my favorite line of code so far
		List<Command> list = stack.peek();
		list.add(fail);
		if (wordScanner.hasNext()) {
			testsAndBracketsCheck(fail, lineScanner, wordScanner);
		}
	}

	/**
	 * Creates a new Filename object with all its respective arguments
	 * read from the Scanner.
	 * @param lineScanner a Scanner of the remaining text
	 * @param wordScanner a Scanner of the line with exists command
	 */
	private void filename(Scanner lineScanner, Scanner wordScanner, boolean positive) {
		String expectedName = wordScanner.next();
		try {
			expectedName = substituteVariables(expectedName);
		} catch (UndefinedVariableException e) {
			System.out.println(e.getMessage());
			System.exit(-1);
		}
		Filename filename = new Filename(substituteVariables(fileName), expectedName, positive);
		List<Command> list = stack.peek();
		list.add(filename);
		if (wordScanner.hasNext()) {
			testsAndBracketsCheck(filename, lineScanner, wordScanner);
		}
	}

	/**
	 * Creates a new Format object with all its respective arguments
	 * read from the Scanner.
	 * @param lineScanner a Scanner of the remaining text
	 * @param wordScanner a Scanner of the line with exists command
	 */
	private void format(Scanner lineScanner, Scanner wordScanner, boolean positive) {
		String extension = wordScanner.next();
		try {
			extension = substituteVariables(extension);
		} catch (UndefinedVariableException e) {
			System.out.println(e.getMessage());
			System.exit(-1);
		}
		Format format = new Format(fileName, extension, positive);
		List<Command> list = stack.peek();
		list.add(format);
		if (wordScanner.hasNext()) {
			testsAndBracketsCheck(format, lineScanner, wordScanner);
		}
	}

	private void terminate(Scanner wordScanner) {
		
	}

	/**
	 * 
	 * @param wordScanner
	 * @return extracted string, with i in front of it if it exists
	 */
	private String extractString(Scanner wordScanner) {
		StringBuilder sbuilder = new StringBuilder();
		String next;
		while (wordScanner.hasNext()) {
			sbuilder.append(next = wordScanner.next());
			if (next.endsWith("\"")) 
				break;
		}
		String string = sbuilder.toString();
		if (string.charAt(0) == '\"') {
			string = string.substring(1);
		}
		if (string.charAt(string.length() - 1) == '\"') {
			string = string.substring(0, string.length() - 1);
		}
		return string;
	}

	/**
	 * In a given string, substitute all variables if they are defined
	 * and replace ':'(expression) with a fit directory structure.
	 * @param string
	 * @return
	 * @throws UndefinedVariableException
	 */
	private String substituteVariables(String string) throws UndefinedVariableException {
		String path = new String(string);
		int position1;
		int position2;
		while ((position1 = path.indexOf("${")) > -1) {
			String key = path.substring(position1 + 2, position2 = path.indexOf('}'));
			String trimmedKey = key.trim();
			String substitution = variablesMap.get(trimmedKey);
			if (substitution == null) {
				throw new UndefinedVariableException("In line "+ lineNumber +
						" an undefined variable is referenced.");
			}
			path = path.substring(0, position1) + substitution + path.substring(position2 + 1);
			path.replace("${"+ trimmedKey +"}", substitution);
		}
		if ((position1 = path.indexOf(':')) > 2) {
			char[] charset = path.toCharArray();
			for (int i = position1; i < charset.length; i++) {
				if (charset[i] == '.') {
					charset[i] = '/';
				}
			}
			charset[position1] = '/';
			path = new String(charset);
		}
		return path;
	}

	/**
	 * Checks whether file type is directory.
	 * @param next f/fi/fil/file or d/di/dir
	 * @return true if next represents a directory, false if not
	 */
	private boolean isItDirectory(String next) {
		next = next.toLowerCase();
		//we already know the input is right, so we just check this
		if (next.contains("f")) {
			return false;
		}
		return true;
	}

	/**
	 * Checks whether there is a fail-test-string and/or a
	 * new-block-bracket in this Scanner. If so, it adds the string
	 * to the current Command and/or makes it possible to recursively
	 * call checkBody() on the new block.
	 * @param command AbstractQuery currently being parsed
	 * @param lineScanner Scanner of remaining text
	 * @param wordScanner Scanner with a fail-test-string and/or a
	 * 						new-block-bracket
	 */
	private void testsAndBracketsCheck(Command command, 
			Scanner lineScanner, Scanner wordScanner) {
		String next = wordScanner.next();
		if (!next.equals("{")) {
			//we don't need the @
			next = next.substring(1) + giveMeAString(wordScanner);
			next = substituteVariables(next);
			command.setFailMessage(next);
			if (wordScanner.hasNext()) {
				next = wordScanner.next();
			} else {
				return;
			}
		}
		//by this point, next certainly contains a '{'
		stack.push(command.getChildren());
		checkBody(lineScanner);
	}

	/**
	 * Reads a set of words from the scanner, ending with \" (or \n)
	 * and creates one String of them, then returns it.
	 * @param wordScanner
	 * @return 
	 */
	private String giveMeAString(Scanner wordScanner) {
		StringBuilder sbuilder = new StringBuilder();
		while (wordScanner.hasNext()) {
			String word = wordScanner.next();
			sbuilder.append(" " + word);
			if (word.endsWith("\"")) 
				break;
		}
		return sbuilder.toString();
	}
	
	/**
	 * Returns a list of error descriptions.
	 * @return a List<String> of errors found
	 */
	public List<String> errors() {
		return errors;
	}
	
	/**
	 * Checks whether any error was found.
	 * @return true there were errors found, false if not
	 */
	public boolean hasErrors() {
		return !(errors.isEmpty());
	}

}
