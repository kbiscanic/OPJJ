package hr.fer.zemris.java.scripting.demo;

import hr.fer.zemris.java.scripting.exec.ObjectMultistack;
import hr.fer.zemris.java.scripting.exec.ValueWrapper;

/**
 * A class which tests the functionality of our ObjectMultistack.
 * @author Jura Šlosel
 *
 */
public class ObjectMultistackDemo {
	
	/**
	 * Does some argument pushing and popping and peeking upon the ObjectMultistack.
	 * @param args not used
	 */
	public static void main(String[] args) {
		ObjectMultistack multistack = new ObjectMultistack();
		
		ValueWrapper year = new ValueWrapper(Integer.valueOf(2000));
		multistack.push("year", year);
		
		ValueWrapper price = new ValueWrapper(200.51);
		multistack.push("price", price);
		
		System.out.println("Current value for year: "+ multistack.peek("year").getValue());
		System.out.println("Current value for price: "+ multistack.peek("price").getValue());
		
		multistack.push("year", new ValueWrapper(Integer.valueOf(1900)));
		System.out.println("Current value for year: "+ multistack.peek("year").getValue());
		
		multistack.peek("year").setValue(
				((Integer)multistack.peek("year").getValue()).intValue() + 50);
		System.out.println("Current value for year: "+ multistack.peek("year").getValue());
		
		multistack.pop("year");
		System.out.println("Current value for year: "+ multistack.peek("year").getValue());
		multistack.peek("year").increment("5");
		
		System.out.println("Current value for year: "+ multistack.peek("year").getValue());
		multistack.peek("year").increment(5);
		System.out.println("Current value for year: "+ multistack.peek("year").getValue());
		multistack.peek("year").increment(5.0);
		System.out.println("Current value for year: "+ multistack.peek("year").getValue());
	}
	
}

