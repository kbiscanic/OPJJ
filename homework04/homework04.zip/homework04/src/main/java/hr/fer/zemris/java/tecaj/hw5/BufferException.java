package hr.fer.zemris.java.tecaj.hw5;

/**
 * Primarily used to tell an Exception with one of Buffers happened 
 * @author Jura Šlosel
 *
 */
public class BufferException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public BufferException(String message) {
		super (message);
	}
	
	public BufferException() {
		super ();
	}
}
