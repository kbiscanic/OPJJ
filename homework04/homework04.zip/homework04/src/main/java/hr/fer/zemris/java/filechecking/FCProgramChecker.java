package hr.fer.zemris.java.filechecking;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A class which scans the input text document for syntax errors in writing
 * a program.
 * @author Jura Šlosel
 *
 */
public class FCProgramChecker {
	private String program;
	private List<String> errors;
	private int lineNumber;
	
	/**
	 * Creates the internal String of program text and starts the checking.
	 * Note that the right form of initializing the object with this constructor
	 * is: new FCProgramString(FCProgramString.removeComments(program)), since this
	 * constructor assumes the input text was rid of comments. This was done for reasons. 
	 * @param program String, text of the program to be checked, WITHOUT COMMENTS
	 */
	public FCProgramChecker(String program) {
		this.program = program;
		errors = new ArrayList<String>();
		this.startCheck();
	}
	
	/**
	 * Initiates checking for syntax errors.
	 */
	private void startCheck() {
		String text = removeComments(this.program);
		Scanner lineScanner = new Scanner(text);
		checkBody(lineScanner, false);
		lineScanner.close();
	}
	
	/**
	 * Gets a Scanner of the remaining text that wasn't read (checked) until now.
	 * This method is used recursively by exists(), fail(), format() and filename()
	 * methods.
	 * @param lineScanner Scanner of the whole text of program
	 * @param openedBracket tells us if this current docBody is a part of a command
	 * 						(true) or the total text (only when initially called is
	 * 						that so)
	 */
	private boolean checkBody(Scanner lineScanner, boolean openedBracket) {
		//ili has next() ?
		while(lineScanner.hasNextLine()) {
			Scanner wordScanner = new Scanner(lineScanner.nextLine());
			lineNumber++;
			String name = wordScanner.next().toLowerCase();
			if (name.equals("def")) {
				def(wordScanner);
			}
			else if (name.equals("terminate")) {
				terminate(wordScanner);
			}
			else if (name.equals("exists") || name.equals("!exists")) {
				exists(lineScanner, wordScanner);
			}
			else if (name.equals("filename") || name.equals("!filename")) {
				filename(lineScanner, wordScanner);
			}
			else if (name.equals("fail") || name.equals("!fail")) {
				fail(lineScanner, wordScanner);
			}
			else if (name.equals("format") || name.equals("!format")) {
				format(lineScanner, wordScanner);
			}
			else if (name.equals("}")) {
				if (openedBracket) {
					wordScanner.close();
					return true;
				} else {
					errors.add("At line "+ lineNumber +" a bracket is closed, where none" +
							" was opened.");
				}
			}	
			else {
				errors.add("At line "+ lineNumber +" the name of command not recognized.");
			};
		}
		return false;
	}

	/**
	 * Checks whether passed "arguments" (in a Scanner) follow the format
	 * of the def command.
	 * @param wordScanner Scanner of the line where a def command starts
	 */
	private void def(Scanner wordScanner) {
		if (wordScanner.hasNext()) {
			checkVariable(wordScanner.next());
		} else {
			errors.add("At line "+ lineNumber +" no argument comes after def.");
		}
		String string;
		if (wordScanner.hasNext()) {
			string = giveMeAString(wordScanner);
			//begins with i? contains funny characters? contains variable? ends with \" ?
			checkString(string);
		} else {
			errors.add("At line "+ lineNumber +" there must be a string as second argument.");
		}
		if (wordScanner.hasNext()) {
			errors.add("At line "+ lineNumber +" there are too many arguments.");
		}
	}

	/**
	 * Checks whether passed "arguments" (in a Scanner) follow the format
	 * of the exists command.
	 * @param lineScanner Scanner of the whole document up to now
	 * @param wordScanner Scanner of the line where an exists command starts
	 */
	private void exists(Scanner lineScanner, Scanner wordScanner) {
		if (wordScanner.hasNext()) {
			checkFileDir(wordScanner.next());
		} else {
			errors.add("At line "+ lineNumber +" no argument comes after exists.");
		}
		//gathers all parts of the next string into one String
		String string;
		if (wordScanner.hasNext()) {
			string = giveMeAString(wordScanner);
			//begins with i? contains funny characters? contains variable? ends with \" ?
			checkString(string);
		} else {
			errors.add("At line "+ lineNumber +" there must be a string as second argument.");
		}
		//is there a fail test? or perchance a { ?
		testsAndBracketsCheck(lineScanner, wordScanner);
	}
	
	/**
	 * Checks whether passed "arguments" (in a Scanner) follow the format
	 * of the fail command.
	 * @param lineScanner Scanner of the whole document up to now
	 * @param wordScanner Scanner of the line where a fail command starts
	 */
	private void fail(Scanner lineScanner, Scanner wordScanner) {
		//fail has no args, only possibly a new section and a fail-message
		testsAndBracketsCheck(lineScanner, wordScanner);
	}

	/**
	 * Checks whether passed "arguments" (in a Scanner) follow the format
	 * of the filename command.
	 * @param lineScanner Scanner of the whole document up to now
	 * @param wordScanner Scanner of the line where a filename command starts
	 */
	private void filename(Scanner lineScanner, Scanner wordScanner) {
		if (wordScanner.hasNext()) {
			checkString(wordScanner.next());
		} else {
			errors.add("At line "+ lineNumber +" no argument comes after exists.");
		}
		testsAndBracketsCheck(lineScanner, wordScanner);
	}

	/**
	 * Checks whether passed "arguments" (in a Scanner) follow the format
	 * of the format command.
	 * @param lineScanner Scanner of the whole document up to now
	 * @param wordScanner Scanner of the line where a format command starts
	 */
	private void format(Scanner lineScanner, Scanner wordScanner) {
		if (wordScanner.hasNext()) {
			checkVariable(wordScanner.next());
		} else {
			errors.add("At line "+ lineNumber +" no argument comes after exists.");
		}
		testsAndBracketsCheck(lineScanner, wordScanner);
	}
	
	/**
	 * Checks whether passed "arguments" (in a Scanner) follow the format
	 * of the terminate command.
	 * @param wordScanner Scanner of the line where a terminate command starts
	 */
	private void terminate(Scanner wordScanner) {
		if (wordScanner.hasNext()) {
			errors.add("At line "+ lineNumber +" an argument is listed next to terminate," +
					" which takes no arguments.");
		}
	}

	/**
	 * The "conditional" commands (exists, filename, format, fail) can have
	 * a fail-section and a new-block-of-commands-section, and this method
	 * checks that for them.
	 * @param lineScanner Scanner of the remaining text of program
	 * @param wordScanner possibly a fail-section and/or a new-block-of-commands-section
	 */
	private void testsAndBracketsCheck(Scanner lineScanner, Scanner wordScanner) {
		while (wordScanner.hasNext()) {
			String next = wordScanner.next();
			//what we just read might be the beginning and/or the end of string
			if (next.charAt(0) == '@' && !next.endsWith("\"")) {
				next = next + giveMeAString(wordScanner);
				//we dont care about the @ at the beginning
				checkString(next.substring(1));
			} else if (next.charAt(0) == '@' && next.endsWith("\"")) {
				checkString(next.substring(1));
			} else if (next.equals("{") && !wordScanner.hasNext()) {
				boolean lastLine = checkBody(lineScanner, true);
				//this happens if we returned, but without a }
				if (!lastLine) {
					errors.add("At line "+ lineNumber +", a '}' is missing.");
				}
			} else if (wordScanner.hasNext()) {
				errors.add("At line "+ lineNumber +" there are too many arguments.");
			}
		}
	}
	
	/**
	 * Checks whether input String represents a directory or file in exists.
	 * @param next a String that should be f/fi/fil/file or d/di/dir
	 */
	private void checkFileDir(String next) {
		next = next.toLowerCase();
		if (next.equals("f") || next.equals("fi") 
				|| next.equals("fil") || next.equals("file")) {
			return;
		} else if (next.equals("d") || next.equals("di") || next.equals("dir")) {
			return;
		} else {
			errors.add("At line "+ lineNumber +" no file or directory mark" +
					" camfe after 'exists'.");
		}
	}

	/**
	 * Checks 'something' that begins with \" but possibly doesn't end with \".
	 * This method checks for that and also for other possible mischiefs done
	 * upon this string.
	 * @param string a possible string
	 */
	private void checkString(String string) {
		if (!string.endsWith("\"")) {
			errors.add("At line "+ lineNumber +" a string was interrupted.");
		}
		//check for "" and i or @ at the beginning
		if ((string.indexOf("i\"") != 0) && string.charAt(0) != '\"') {
			errors.add("At line "+ lineNumber +" something which isn't string is where " +
					"a string should be.");
			return;
		}
		String tmp = new String(string);
		int position1;
		int position2 = tmp.indexOf("}");
		while ((position1 = tmp.indexOf("${")) > -1 && 
				(position2 = tmp.indexOf("}")) > position1) {
			
			if (position2 > position1) {
				String var = tmp.substring(position1 + 2, position2);
				checkVariable(var);
			}
			else {
				errors.add("At line "+ lineNumber +" string syntax is wrong.");
			}
			//tmp.replaceFirst("\\$\\{.*\\}", "");
			tmp = tmp.substring(0, position1) + tmp.substring(position2 + 1, tmp.length());
		}
		if (tmp.contains("{") || tmp.contains("}") || tmp.contains("$")
				|| tmp.contains("\t") || tmp.substring(2).indexOf("\"") != tmp.length() - 3) {
			errors.add("At line "+ lineNumber +" string syntax is wrong.");
		}
		if (tmp.indexOf(':') != tmp.lastIndexOf(':')) {
			errors.add("At line "+ lineNumber +" a string has more than one colon (:).");
		}
	}

	/**
	 * Reads a set of words from the scanner, ending with \" (or \n)
	 * and creates one String of them, then returns it.
	 * @param wordScanner
	 * @return 
	 */
	private String giveMeAString(Scanner wordScanner) {
		StringBuilder sbuilder = new StringBuilder();
		while (wordScanner.hasNext()) {
			String word = wordScanner.next();
			sbuilder.append(word);
			if (word.endsWith("\"")) 
				break;
		}
		return sbuilder.toString();
	}

	/**
	 * Checks whether input String follows syntax of a variable
	 * @param var possible variable
	 */
	private void checkVariable(String var) {
		var = var.trim();
		Pattern pattern = Pattern.compile("[a-zA-Z]|(\\w*\\.*)*");
		Matcher matcher = pattern.matcher(var);
		if (!matcher.matches()) {
			errors.add("At line "+ lineNumber +" variable syntax is wrong.");
		}
	}

	/**
	 * Returns the List of all syntax errors found during the check.
	 * @return the List<String> of errors
	 */
	public List<String> errors() {
		return errors;
	}
	
	/**
	 * Checks whether there were any errors in the program.
	 * @return List<String> of errors
	 */
	public boolean hasErrors() {
		return !errors.isEmpty();
	}
	
	/**
	 * Removes comments and empty lines from input String, then
	 * returns it modified.
	 * @param initial the initial program (String)
	 * @return input text without comments or empty lines
	 */
	public static String removeComments(String initial) {
		Scanner scanner = new Scanner(initial);
		StringBuilder sbuilder = new StringBuilder();
		//ILI HASNEXT()?
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			line = line.trim();
			if (!(line.equals("")) && !(line.charAt(0) == '#')) {
				sbuilder.append(line + "\n");
			}
		}
		/* removes the last \n at the end of file
		if (sbuilder.charAt(sbuilder.length()) == '\n') {
			sbuilder.deleteCharAt(sbuilder.length());
		}
		*/
		scanner.close();
		return sbuilder.toString();
	}
	
}
