package hr.fer.zemris.java.filechecking.demo;

import hr.fer.zemris.java.filechecking.FCFileVerifier;
import hr.fer.zemris.java.filechecking.FCProgramChecker;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

/**
 * Reads three arguments from commandline and uses them to
 * check the programs syntax then execute commands.
 * @author Jura Šlosel
 *
 */
public class FCDemo {

	/**
	 * @param args 3 Strings: 1. path to the .zip file on disk,
	 * 						  2. original file name
	 * 						  3. .txt file with instructions
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		if (args.length != 3) {
			throw new IllegalArgumentException("3 arguments! No more and no less!");
		}
		File file = new File(args[0]); // zadaj neku ZIP arhivu
		String program = ucitaj(args[2]); // učitaj program iz datoteke
		String fileName = args[1]; // definiraj stvarno ime arhive
		
		FCProgramChecker checker = new FCProgramChecker(program);
		
		if(checker.hasErrors()) {
			System.out.println("Errors in program!");
			System.out.println("When an error is listed, the line numbering doesn't" +
					" acknowlege (count) comments or empty lines.\n");
			for(String error : checker.errors()) {
				System.out.println(error);
			}
			System.out.println("I give up now.");
			System.exit(0);
		}
		
		Map<String,Object> initialData = new HashMap<>();
		initialData.put("jmbag", "0012345678");
		initialData.put("lastName", "Perić");
		initialData.put("firstName", "Pero");
		
		FCFileVerifier verifier = new FCFileVerifier(file, fileName, program, initialData);
		
		if(!verifier.hasErrors()) {
			System.out.println("Nothing wrong with this zip file.");
		} else {
			System.out.println("You messed up somewhere. Here errors:\n");
			for(String error : verifier.errors()) {
				System.out.println(error);
			}
		}
	}

	/**
	 * Creates an InputStream to read from the file with input name,
	 * then removes comments and empty lines, and returns a String
	 * made of that.
	 * @param program name of file to turn to String
	 * @return String version of input program, with no comments or empty lines
	 * @throws IOException 
	 */
	private static String ucitaj(String program) throws IOException {
		FileInputStream fstream = new FileInputStream(program);
		StringBuilder sbuilder = new StringBuilder();
		byte[] bytes = new byte[4096];
		int read;
		while ((read = fstream.read(bytes)) != -1) {
			sbuilder.append(FCProgramChecker.removeComments(
					new String(bytes, 0, read, Charset.defaultCharset())));
		}
		fstream.close();
		return sbuilder.toString();
	}

}
