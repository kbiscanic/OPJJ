/**
 * Herein is a small implementation of encryption, decryption and 
 * digestion.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.tecaj.hw5.crypto;