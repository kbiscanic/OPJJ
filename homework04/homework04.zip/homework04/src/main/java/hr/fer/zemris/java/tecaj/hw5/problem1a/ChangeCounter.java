package hr.fer.zemris.java.tecaj.hw5.problem1a;

/**
 * An implementation of the IntegerStorageObserver.
 * @author Jura Šlosel
 *
 */
public class ChangeCounter implements IntegerStorageObserver {
	private int changeCounter;
	
	/**
	 * Prints the number of times the value in IntgerStorage has been changed
	 * since this observer has first been recorded and the value of object has 
	 * been changed whilst this observer was active.
	 */
	@Override
	public void valueChanged(IntegerStorage istorage) {
		changeCounter++;
		System.out.println("Number of value changes since tracking: " + changeCounter);
	}
	
}
