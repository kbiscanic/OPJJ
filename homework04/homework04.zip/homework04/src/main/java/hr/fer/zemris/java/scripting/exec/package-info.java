/**
 * Contains a class which encapsulates different types of Objects as numerical values and
 * a class which makes a Stack-Map functionality with objects of first class of elements.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.scripting.exec;