package hr.fer.zemris.java.tecaj.hw5.problem1b;

import hr.fer.zemris.java.tecaj.hw5.problem1b.IntegerStorageObserver;

/**
 * An implementation of the IntegerStorageObserver using IntegerStorageChanged.
 * @author Jura Šlosel
 *
 */
public class ChangeCounter implements IntegerStorageObserver {
	private int count;
	
	/**
	 * Prints the number of changes of the internally stored value in the 
	 * IntegerStorage since this observer was first registered.
	 */
	@Override
	public void valueChanged(IntegerStorageChanged change) {
		count++;
		System.out.println("Number of value changes since tracking: " + count);
	}

}
