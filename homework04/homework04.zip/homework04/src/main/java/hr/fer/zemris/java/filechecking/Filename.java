package hr.fer.zemris.java.filechecking;

import java.util.ArrayList;
import java.util.List;

/**
 * Class for the filename command. Holds its argument: expected filename. Defines its execute().
 * @author Jura Šlosel
 *
 */
public class Filename extends Command {
	private String expectedName;
	private String fileName;
	
	/**
	 * 
	 * @param fileName
	 * @param expectedName
	 * @param positive
	 */
	public Filename(String fileName, String expectedName, boolean positive) {
		this.positive = positive;
		this.expectedName = crop(expectedName);
		children = new ArrayList<Command>();
		this.fileName = fileName;
	}
	
	/**
	 * Internally, strings are kept with "" so this removes them before
	 * the string is used to search a file
	 * @param string pathname with ""
	 * @return pathname
	 */
	private String crop(String string) {
		return string.substring(1, string.length() - 1);
	}

	/**
	 * Checks whether input filename matches the real filename.
	 */
	@Override
	public void execute(List<String> errors) {
		boolean equals = false;
		if (fileName.equals(expectedName)) {
			equals = true;
		}
		if (equals && positive) {
			testState = true;
		}
		if (!equals && !positive) {
			testState = true;
		}
		if (!testState) {
			if (failMessage == null) {
				generateFailMessage();
			}
			errors.add(failMessage);
		} else {
			int size;
			if ((size = children.size()) != 0) {
				for (int i = 0; i < size; i++) {
					Command child = children.get(i);
					child.execute(errors);
				}
			}
		}
	}

	/**
	 * If no fail message was set, this sets a generic one.
	 */
	private void generateFailMessage() {
		failMessage = "A 'filename' command with no fail message has failed.\n" +
				"\tIt's argument is " + fileName;
	}

}
