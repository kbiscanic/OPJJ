/**
 * Contains some classes for parsing and executing a program for
 * checking contents of a zip archive through a set of predefined 
 * queries.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.filechecking;