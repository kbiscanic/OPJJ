/**
 * Contains a simple implementation of the basic Observer pattern object and observer.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.tecaj.hw5.problem1a;