package hr.fer.zemris.java.filechecking;

import java.util.ArrayList;
import java.util.List;

/**
 * Class for a fail command. Holds its argument: fail message. Defines its execute().
 * @author Jura Šlosel
 *
 */
public class Fail extends Command {

	/**
	 * Initializes fields.
	 * @param pathString String that represents the path to a file in zip
	 * @param positive true if no ! preceded 'exists', false otherwise
	 */
	public Fail(boolean positive) {
		this.positive = positive;
		this.children = new ArrayList<Command>();
	}
	
	/**
	 * If the test failed (no !), the failtext is printed, else
	 * the block of children is executed.
	 */
	@Override
	public void execute(List<String> errors) {
		if (!testState) {
			if (failMessage == null) {
				generateFailMessage();
			}
			errors.add(failMessage);
		} else {
			int size;
			if ((size = children.size()) != 0) {
				for (int i = 0; i < size; i++) {
					Command child = children.get(i);
					child.execute(errors);
				}
			}
		}
	}

	/**
	 * If no fail message was set, this sets a generic one.
	 */
	private void generateFailMessage() {
		failMessage = "This is a genereic fail of a 'fail' command with no failText.";
	}

}
