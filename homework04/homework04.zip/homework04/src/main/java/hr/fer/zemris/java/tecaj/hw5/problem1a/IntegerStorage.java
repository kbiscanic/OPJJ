package hr.fer.zemris.java.tecaj.hw5.problem1a;

/**
 * An implementation of the object in the Observer pattern.
 * @author Jura Šlosel
 *
 */
public class IntegerStorage {
	private int value;
	private IntegerStorageObserver observer;
	
	/**
	 * Sets the initial value of {@code value}.
	 * @param initialValue the initial value of {@code value}
	 */
	public IntegerStorage(int initialValue) {
		this.value = initialValue;
	}
	
	/**
	 * Sets the observer that is to track changes of this object and 
	 * performs actions upon it.
	 * @param observer IntegerStorageObserver to be active
	 */
	public void setObserver(IntegerStorageObserver observer) {
		this.observer = observer;
	}
	
	/**
	 * Removes the current observer.
	 */
	public void clearObserver() {
		this.observer = null;
	}
	
	/**
	 * Returns {@code value}.
	 * @return value
	 */
	public int getValue() {
		return value;
	}
	
	/**
	 * Sets {@code this.value} to {@code value} and tells the active observer a
	 * change has been made.
	 * @param value the new value of {@code this.value}
	 */
	public void setValue(int value) {
		if(this.value!=value) {
			this.value = value;
			if(observer!=null) {
				observer.valueChanged(this);
			}
		}
	}
	
}
