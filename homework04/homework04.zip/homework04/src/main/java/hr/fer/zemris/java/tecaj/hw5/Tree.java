package hr.fer.zemris.java.tecaj.hw5;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

public class Tree implements ShellCommand {

	/**
	 * Prints as a tree structure all files and subdirectories of the
	 * passed directory.
	 */
	@Override
	public ShellStatus executeCommand(BufferedReader in, BufferedWriter out,
			String[] arguments) {
		
		Path dir = Paths.get(arguments[0]);
		dir = Paths.get("D:/Fucks");
		
		checkDirectory(dir, out);
		
		try {
			Files.walkFileTree(dir, new FireVisitor(out));
		} catch (IOException e) {
			throw new CommandException("An IOException occured while traversing the tree.\n");
		}
		
		return ShellStatus.CONTINUE;
	}
	
	/**
	 * Checks whether passed Path is a directory and does it exist.
	 * @param dir Path
	 * @param out BufferedWriter, stdOut
	 */
	private void checkDirectory(Path dir, BufferedWriter out) {
		if (!dir.toFile().isDirectory()) {
			throw new CommandException("Argument is no directory.\n");
		}
		
		if (!dir.toFile().exists()) {
			throw new CommandException("Argument file doesn't exist.\n");
		}
	}

	static class FireVisitor implements FileVisitor<Path> {
		int indent = 0;
		BufferedWriter out;
		
		public FireVisitor(BufferedWriter out) {
			this.out = out;
		}
		
		@Override
		public FileVisitResult preVisitDirectory(Path dir,
				BasicFileAttributes attrs) throws IOException {
			String output;
			if (indent == 0) {
				output = dir.getFileName().toString();
				//output = dir.getFileName().toString();
			} else {
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < indent; i++) sb.append(" ");
				output = sb.toString() + dir.getFileName();
			}
			out.write(output);
			out.write("\n");
			indent += 2;
			out.flush();
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
				throws IOException {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < indent; i++) sb.append(" ");
			String output = sb.toString() + file.getFileName();
			out.write(output);
			out.write("\n");
			out.flush();
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc)
				throws IOException {
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc)
				throws IOException {
			indent -= 2;
			return FileVisitResult.CONTINUE;
		}
		
	}

}
