package hr.fer.zemris.java.scripting.exec;

/**
 * A wrapper around an Integer or double, depending on what is passed to constructor
 * or to one of the methods. The class allows for limited value-wrapping functionality. 
 * @author Jura Šlosel
 *
 */
public class ValueWrapper {
	private Object value;

	/**
	 * Initializes this.value to a Double or Integer representation
	 * of value.
	 * @param value Integer, Double, String or null to represent our value;
	 * null is transformed to Integer(0)
	 */
	public ValueWrapper(Object value) {
		this.value = determineType(value);
	}
	
	/**
	 * Getter.
	 * @return value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Setter; some modifications must be made upon the argument so it is
	 * stored either as Integer or Double.
	 * @param value Integer, Double, String or null, new numeric value of this.value
	 */
	public void setValue(Object value) {
		this.value = determineType(value);
	}

	/**
	 * Increments this.value by incValue.
	 * @param incValue value to add to this.value
	 */
	public void increment(Object incValue) {
		Object newVal = determineType(incValue);
		value = operation(this.value, newVal, '+');
	}
	
	/**
	 * Decrements this.value by decValue.
	 * @param decValue value to subside this.value with
	 */
	public void decrement(Object decValue) {
		Object newVal = determineType(decValue);
		value = operation(this.value, newVal, '-');
	}
	
	/**
	 * Multiplies this.value by mulValue.
	 * @param mulValue value to multiply this.value with
	 */
	public void multiply(Object mulValue) {
		Object newVal = determineType(mulValue);
		value = operation(this.value, newVal, '*');
	}
	
	/**
	 * Divides this.value by mulValue.
	 * @param divValue value to divide this.value with
	 */
	public void divide(Object divValue) {
		Object newVal = determineType(divValue);
		value = operation(this.value, newVal, '/');
	}
	
	/**
	 * Compares this.value with withValue.
	 * @param withValue value to compare this.value to
	 * @return 1 if this.value is greater than, -1 if less than, 0 if equal to withValue
	 */
	public int numCompare(Object withValue) {
		Object newVal = determineType(withValue);
		Integer result = (Integer)operation(this.value, newVal, '|');
		return result;
	}
	
	/**
	 * Determines whether the input value was in fact an Integer, a Double,
	 * a String or null. It throws an exception if value is none of these
	 * and returns an Integer or Double if it is.
	 * @param value the value whose exact type we wish to know
	 * @return value cast or parsed to Integer or Double
	 */
	private Object determineType(Object value) {
		if (value == null) {
			return (Integer.valueOf(0));
		}
		if (value instanceof Integer) {
			return (Integer)value;
		}
		if (value instanceof Double) {
			return (Double)value;
		}
		if (value instanceof String) {
			try {
				String string = (String)value;
				Integer integer = Integer.parseInt(string);
				return integer;
			} catch (NumberFormatException e) {
				//do nothing, let's see if its double
			}
			try {
				String string = (String)value;
				Double doubleVal = Double.parseDouble(string);
				return doubleVal;
			} catch (NumberFormatException e) {
				throw new IllegalArgumentException(
						"The input String was nor Integer nor Double in form!");
			}
		} else {
			throw new IllegalArgumentException(
					"The input can be Integer, Double or String!");
		}
	}
	
	/**
	 * Performs an arithmetic operation, specified by the input char, on two
	 * other characters.
	 * @param first should be this.value
	 * @param second other parameter of arithmetic operation
	 * @param operation +, -, *, /, | (the last one is for comparison)
	 */
	private Object operation(Object first, Object second, char operation) {
		char doubleOrInt = doubleOrInt(first, second);
		switch (doubleOrInt) {
		case 'd' :
			Double double1;
			Double double2;
			if (first instanceof Integer) {
				double1 = new Double(((Integer) first).intValue());
			} else {
				double1 = (Double)first;
			}
			if (second instanceof Integer) {
				double2 = new Double(((Integer) second).intValue() + 0.0);
			} else {
				double2 = (Double)second;
			}
			switch (operation) {
			case '+' : return (Double)(double1 + double2);
			case '-' : return (Double)(double1 - double2);
			case '*' : return (Double)(double1 * double2);
			case '/' : return (Double)(double1 / double2);
			case '|' : 
				if (double1.doubleValue() < double2.doubleValue()) {
					return new Integer(-1);
				}
				if (double1.doubleValue() > double2.doubleValue()) {
					return new Integer(1);
				}
				return new Integer(0);		
			}
			break;
		case 'i' :
			Integer int1 = (Integer)first;
			Integer int2 = (Integer)second;
			switch (operation) {
			case '+' : return (Integer)(int1 + int2);
			case '-' : return (Integer)(int1 - int2);
			case '*' : return (Integer)(int1 * int2);
			case '/' : return (Integer)(int1 / int2);
			case '|' : 
				if (int1.intValue() < int2.intValue()) {
					return new Integer(-1);
				}
				if (int1.intValue() > int2.intValue()) {
					return new Integer(1);
				}
				return new Integer(0);		
			}
			break;
		default : break;
		}
		//if we came here, something wrong happened. the method should have returned
		throw new RuntimeException(
				"The practically unreachable code in ValueWrapper.operation() was reached!");
	}

	/**
	 * Checks if any of parameters is Double and returns 'd'if so
	 * and returns 'i' if not. It is expected that arguments are either 
	 * Integer or Double and nothing else.
	 * @param first first argument
	 * @param second second argument
	 * @return 'd' if at least one is Double, 'i' if they're both Integer
	 */
	private char doubleOrInt(Object first, Object second) {
		if (first instanceof Double) {
			return 'd';
		}
		if (second instanceof Double) {
			return 'd';
		}
		if (second == null) {
			second = new Integer(0);
		}
		return 'i';
	}
	
}
