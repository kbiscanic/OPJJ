package hr.fer.zemris.java.filechecking;

import java.util.ArrayList;
import java.util.List;

/**
 * Class for a format command. Holds its argument: expected format. Defines its execute().
 * @author Jura Šlosel
 *
 */
public class Format extends Command {
	private String extension;
	private String fileName;
	
	/**
	 * Initializes fields.
	 * @param fileName name of original file
	 * @param extension expected extension that is checked
	 * @param positive true if no !
	 */
	public Format(String fileName, String extension, boolean positive) {
		this.extension = extension;
		this.positive = positive;
		this.children = new ArrayList<Command>();
		this.fileName = fileName;
	}
	
	/**
	 * Checks whether the format of the file matches expected format.
	 */
	@Override
	public void execute(List<String> errors) {
		String ext = getExtension();
		if (extension.equals(ext)) {
			testState = true;
		}
		if (!testState) {
			if (failMessage == null) {
				generateFailMessage();
			}
			errors.add(failMessage);
		} else {
			int size;
			if ((size = children.size()) != 0) {
				for (int i = 0; i < size; i++) {
					Command child = children.get(i);
					child.execute(errors);
				}
			}
		}
	}

	/**
	 * If no fail message was set, this sets a generic one.
	 */
	private void generateFailMessage() {
		failMessage = "A 'format' command with no fail message has failed.\n" +
				"It's argument is: " + extension;
	}

	/**
	 * Gets the real extension of the input file.
	 * @return extension of the file, according to fileName
	 */
	private String getExtension() {
		if (fileName.contains(".")) {
			String ext = fileName.substring(fileName.lastIndexOf('.'));
			return ext;
		}
		return null;
	}

}
