/**
 * Contains a simplified Observer pattern object and observer, but with
 * a link class added.
 * @author Jura Šlosel
 *
 */
package hr.fer.zemris.java.tecaj.hw5.problem1b;