package hr.fer.zemris.java.tecaj.scripting.exec;

import static org.junit.Assert.*;
import junit.framework.Assert;
import hr.fer.zemris.java.scripting.exec.ValueWrapper;

import org.junit.Test;

public class ValueWrapperTest {
	ValueWrapper wrapper;
	
	@Test
	public void testConstructor1() {
		wrapper = new ValueWrapper(null);
		Object o = wrapper.getValue();
		Assert.assertTrue(o instanceof Integer);
		Integer i = (Integer)o;
		Assert.assertTrue(i.equals(0));
	}
	
	@Test
	public void testConstructor2() {
		wrapper = new ValueWrapper(10);
		Object o = wrapper.getValue();
		Assert.assertTrue(o instanceof Integer);
		Integer i = (Integer)o;
		Assert.assertTrue(i.equals(10));
	}
	
	@Test
	public void testConstructor3() {
		wrapper = new ValueWrapper("10");
		Object o = wrapper.getValue();
		Assert.assertTrue(o instanceof Integer);
		Integer i = (Integer)o;
		Assert.assertTrue(i.equals(10));
	}
	
	@Test
	public void testConstructor4() {
		wrapper = new ValueWrapper("10.0375");
		Object o = wrapper.getValue();
		Assert.assertTrue(o instanceof Double);
		Double i = (Double)o;
		Assert.assertTrue(i.equals(10.0375));
	}
	
	@Test
	public void testConstructor5() {
		wrapper = new ValueWrapper(10.0375);
		Object o = wrapper.getValue();
		Assert.assertTrue(o instanceof Double);
		Double i = (Double)o;
		Assert.assertTrue(i.equals(10.0375));
	}
	
	@Test
	public void testGetValue() {
		wrapper = new ValueWrapper("10.0375");
		Assert.assertTrue(wrapper.getValue().equals(10.0375));
	}
	
	@Test
	public void testSetValue() {
		wrapper = new ValueWrapper("10.0375");
		wrapper.setValue(10);
		Assert.assertTrue(wrapper.getValue().equals(10));
		wrapper.setValue(10.0);
		Assert.assertTrue(wrapper.getValue().equals(10.0));
		wrapper.setValue("10.066");
		Assert.assertTrue(wrapper.getValue().equals(10.066));
		wrapper.setValue("456");
		Assert.assertTrue(wrapper.getValue().equals(456));
		wrapper.setValue(null);
		Assert.assertTrue(wrapper.getValue().equals(0));
	}
	
	@Test
	public void testIncrement() {
		wrapper = new ValueWrapper("10");
		wrapper.increment(10);
		Assert.assertTrue(wrapper.getValue().equals(20));
		wrapper.increment("10");
		Assert.assertTrue(wrapper.getValue().equals(30));
		wrapper.increment(10.35);
		Assert.assertEquals(wrapper.getValue(), 40.35);
		wrapper.increment("10.35");
		Assert.assertEquals(wrapper.getValue(), 50.70);
	}
	
	@Test
	public void testDecrement() {
		wrapper = new ValueWrapper("10.0");
		wrapper.decrement(10);
		Assert.assertEquals(wrapper.getValue(), 0.0);
		wrapper.decrement("10");
		Assert.assertEquals(wrapper.getValue(), -10.0);
		wrapper.decrement(10.50);
		Assert.assertEquals(wrapper.getValue(), -20.50);
		wrapper.decrement("-10.50");
		Assert.assertEquals(wrapper.getValue(), -10.0);
	}
	
	@Test
	public void testMultiply() {
		wrapper = new ValueWrapper("10.0");
		wrapper.multiply(10);
		Assert.assertEquals(wrapper.getValue(), 100.0);
		wrapper.multiply("10");
		Assert.assertEquals(wrapper.getValue(), 1000.0);
		wrapper.multiply(0.5);
		Assert.assertEquals(wrapper.getValue(), 500.0);
		wrapper.multiply("-0.5");
		Assert.assertEquals(wrapper.getValue(), -250.0);
	}
	
	@Test
	public void testDivide() {
		wrapper = new ValueWrapper("10000");
		wrapper.divide(10);
		Assert.assertEquals(wrapper.getValue(), 1000);
		wrapper.divide("10");
		Assert.assertEquals(wrapper.getValue(), 100);
		wrapper.divide(0.5);
		Assert.assertEquals(wrapper.getValue(), 200.0);
		wrapper.divide("-0.5");
		Assert.assertEquals(wrapper.getValue(), -400.0);
	}
	
	@Test
	public void testnumCompare() {
		wrapper = new ValueWrapper("10000");
		Assert.assertEquals(wrapper.numCompare(10), 1);
		Assert.assertEquals(wrapper.numCompare("10000"), 0);
		Assert.assertEquals(wrapper.numCompare(100010), -1);
		Assert.assertEquals(wrapper.numCompare(10000.0), 0);
		Assert.assertEquals(wrapper.numCompare(10001.0), -1);
		Assert.assertEquals(wrapper.numCompare("1000.1"), 1);
	}	

}
