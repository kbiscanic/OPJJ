package hr.fer.zemris.java.tecaj.scripting.exec;

import static org.junit.Assert.*;
import junit.framework.Assert;
import hr.fer.zemris.java.scripting.exec.EmptyStackException;
import hr.fer.zemris.java.scripting.exec.ObjectMultistack;
import hr.fer.zemris.java.scripting.exec.ValueWrapper;

import org.junit.Test;

public class ObjectMultistackTest {
	ObjectMultistack stack;
	
	@Test
	public void testIsEmpty1() {
		stack = new ObjectMultistack();
		Assert.assertTrue(stack.isEmpty());
		stack.push("lol", new ValueWrapper("10"));
		Assert.assertFalse(stack.isEmpty());
	}

	@Test
	public void testPushAndPeek() {
		stack = new ObjectMultistack();
		stack.push("lol", new ValueWrapper("10"));
		stack.push("druga", new ValueWrapper(10.2));
		stack.push("nah", new ValueWrapper(5567));
		Assert.assertEquals(stack.peek("lol").getValue(), 10);
		Assert.assertEquals(stack.peek("lol").getValue(), 10);
		Assert.assertEquals(stack.peek("druga").getValue(), 10.2);
		Assert.assertEquals(stack.peek("nah").getValue(), 5567);
	}
	
	@Test
	public void testPushAndPop() {
		stack = new ObjectMultistack();
		stack.push("lol", new ValueWrapper("10"));
		stack.push("lol", new ValueWrapper("15"));
		stack.push("druga", new ValueWrapper(10.2));
		stack.push("druga", new ValueWrapper(132));
		stack.push("nah", new ValueWrapper(5567));
		Assert.assertEquals(stack.pop("lol").getValue(), 15);
		Assert.assertEquals(stack.pop("lol").getValue(), 10);
		Assert.assertEquals(stack.pop("druga").getValue(), 132);
		Assert.assertEquals(stack.pop("druga").getValue(), 10.2);
		Assert.assertEquals(stack.pop("nah").getValue(), 5567);
	}
	
	@Test (expected = EmptyStackException.class)
	public void testPopException1() {
		stack = new ObjectMultistack();
		stack.pop("lol");
	}
	
	@Test (expected = EmptyStackException.class)
	public void testPekException1() {
		stack = new ObjectMultistack();
		stack.peek("lol");
	}
	
	@Test (expected = EmptyStackException.class)
	public void testPopException2() {
		stack = new ObjectMultistack();
		stack.push("lol", new ValueWrapper("10"));
		stack.push("lol", new ValueWrapper("15"));
		stack.push("druga", new ValueWrapper(10.2));
		stack.push("lol", new ValueWrapper("30"));
		stack.pop("lol");
		stack.pop("lol");
		stack.pop("lol");
		stack.pop("lol");
	}
	
	@Test (expected = EmptyStackException.class)
	public void testPeekException2() {
		stack = new ObjectMultistack();
		stack.push("lol", new ValueWrapper("10"));
		stack.push("lol", new ValueWrapper("15"));
		stack.push("druga", new ValueWrapper(10.2));
		stack.push("lol", new ValueWrapper("30"));
		stack.pop("lol");
		stack.pop("lol");
		stack.pop("lol");
		stack.peek("lol");
	}
	
}
